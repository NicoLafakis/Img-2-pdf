import ImageToPDF from './components/ImageToPDF'

function App() {
  return <ImageToPDF />
}

export default App
