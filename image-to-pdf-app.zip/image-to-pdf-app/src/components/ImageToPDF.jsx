import React, { useState, useRef } from "react";
import { jsPDF } from "jspdf";
import { FileImage, Trash2, Download, Plus, ArrowUp, ArrowDown, RotateCw } from "lucide-react";

export default function ImageToPDF() {
  const [images, setImages] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [pdfName, setPdfName] = useState("my-document");
  const fileInputRef = useRef(null);

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    processFiles(files);
    e.target.value = "";
  };

  const processFiles = (files) => {
    const imageFiles = files.filter((file) => file.type.startsWith("image/"));

    imageFiles.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          setImages((prev) => [
            ...prev,
            {
              id: Date.now() + Math.random(),
              src: e.target.result,
              name: file.name,
              width: img.width,
              height: img.height,
              rotation: 0,
            },
          ]);
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (id) => {
    setImages((prev) => prev.filter((img) => img.id !== id));
  };

  const moveImage = (index, direction) => {
    const newIndex = index + direction;
    if (newIndex < 0 || newIndex >= images.length) return;

    const newImages = [...images];
    [newImages[index], newImages[newIndex]] = [newImages[newIndex], newImages[index]];
    setImages(newImages);
  };

  const rotateImage = (id) => {
    setImages((prev) =>
      prev.map((img) =>
        img.id === id ? { ...img, rotation: (img.rotation + 90) % 360 } : img
      )
    );
  };

  const generatePDF = async () => {
    if (images.length === 0) return;

    setIsGenerating(true);

    try {
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "pt",
        format: "a4",
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 20;

      for (let i = 0; i < images.length; i++) {
        if (i > 0) pdf.addPage();

        const img = images[i];
        const isRotated90or270 = img.rotation === 90 || img.rotation === 270;

        // Calculate effective dimensions after rotation
        let effectiveWidth = isRotated90or270 ? img.height : img.width;
        let effectiveHeight = isRotated90or270 ? img.width : img.height;

        // Calculate scale to fit page
        const availableWidth = pageWidth - 2 * margin;
        const availableHeight = pageHeight - 2 * margin;
        const scale = Math.min(
          availableWidth / effectiveWidth,
          availableHeight / effectiveHeight
        );

        const scaledWidth = effectiveWidth * scale;
        const scaledHeight = effectiveHeight * scale;

        // Center the image
        const x = (pageWidth - scaledWidth) / 2;
        const y = (pageHeight - scaledHeight) / 2;

        // Apply rotation if needed
        if (img.rotation !== 0) {
          const centerX = pageWidth / 2;
          const centerY = pageHeight / 2;

          pdf.saveGraphicsState();

          const drawWidth = img.width * scale;
          const drawHeight = img.height * scale;

          const angleRad = (img.rotation * Math.PI) / 180;

          const cos = Math.cos(angleRad);
          const sin = Math.sin(angleRad);

          pdf.setCurrentTransformationMatrix(
            new pdf.Matrix(cos, sin, -sin, cos, centerX, centerY)
          );

          pdf.addImage(
            img.src,
            "JPEG",
            -drawWidth / 2,
            -drawHeight / 2,
            drawWidth,
            drawHeight
          );

          pdf.restoreGraphicsState();
        } else {
          pdf.addImage(img.src, "JPEG", x, y, scaledWidth, scaledHeight);
        }
      }

      pdf.save(`${pdfName || "document"}.pdf`);
    } catch (error) {
      console.error("Error generating PDF:", error);
      alert("Error generating PDF. Please try again.");
    }

    setIsGenerating(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-lg mx-auto px-4 py-6 pb-32">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-600 rounded-2xl mb-3 shadow-lg shadow-purple-500/30">
            <FileImage className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">Image to PDF</h1>
          <p className="text-purple-200 text-sm mt-1">Convert your images into a single PDF</p>
        </div>

        {/* File Name Input */}
        <div className="mb-4">
          <label className="block text-purple-200 text-sm mb-2">PDF Filename</label>
          <input
            type="text"
            value={pdfName}
            onChange={(e) => setPdfName(e.target.value)}
            placeholder="my-document"
            className="w-full px-4 py-3 bg-white/10 border border-purple-500/30 rounded-xl text-white placeholder-purple-300/50 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
        </div>

        {/* Upload Area */}
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-purple-500/50 rounded-2xl p-8 text-center cursor-pointer hover:border-purple-400 hover:bg-purple-500/10 transition-all duration-200"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileSelect}
            className="hidden"
          />
          <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-600/30 rounded-xl mb-3">
            <Plus className="w-6 h-6 text-purple-300" />
          </div>
          <p className="text-purple-200 font-medium">Tap to add images</p>
          <p className="text-purple-400 text-sm mt-1">JPG, PNG, GIF, WebP</p>
        </div>

        {/* Image Count */}
        {images.length > 0 && (
          <div className="mt-4 text-center">
            <span className="inline-flex items-center px-3 py-1 bg-purple-600/30 rounded-full text-purple-200 text-sm">
              {images.length} image{images.length !== 1 ? "s" : ""} selected
            </span>
          </div>
        )}

        {/* Image List */}
        <div className="mt-4 space-y-3">
          {images.map((img, index) => (
            <div
              key={img.id}
              className="bg-white/10 backdrop-blur-sm rounded-xl p-3 flex items-center gap-3 border border-purple-500/20"
            >
              {/* Thumbnail */}
              <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-black/30 flex-shrink-0">
                <img
                  src={img.src}
                  alt={img.name}
                  className="w-full h-full object-cover"
                  style={{ transform: `rotate(${img.rotation}deg)` }}
                />
                {img.rotation !== 0 && (
                  <div className="absolute bottom-0 right-0 bg-purple-600 text-white text-xs px-1 rounded-tl">
                    {img.rotation}°
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium truncate">{img.name}</p>
                <p className="text-purple-300 text-xs">
                  Page {index + 1} • {img.width}×{img.height}
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1">
                <button
                  onClick={() => rotateImage(img.id)}
                  className="p-2 text-purple-300 hover:text-white hover:bg-purple-600/30 rounded-lg transition-colors"
                  title="Rotate 90°"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
                <button
                  onClick={() => moveImage(index, -1)}
                  disabled={index === 0}
                  className="p-2 text-purple-300 hover:text-white hover:bg-purple-600/30 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                  title="Move up"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <button
                  onClick={() => moveImage(index, 1)}
                  disabled={index === images.length - 1}
                  className="p-2 text-purple-300 hover:text-white hover:bg-purple-600/30 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                  title="Move down"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
                <button
                  onClick={() => removeImage(img.id)}
                  className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/20 rounded-lg transition-colors"
                  title="Remove"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {images.length === 0 && (
          <div className="mt-8 text-center text-purple-400">
            <p>No images added yet</p>
            <p className="text-sm mt-1">Your images will appear here</p>
          </div>
        )}
      </div>

      {/* Fixed Bottom Button */}
      {images.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-slate-900 via-slate-900/95 to-transparent">
          <div className="max-w-lg mx-auto">
            <button
              onClick={generatePDF}
              disabled={isGenerating}
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 disabled:from-purple-800 disabled:to-pink-800 text-white font-semibold rounded-xl shadow-lg shadow-purple-500/30 flex items-center justify-center gap-2 transition-all duration-200"
            >
              {isGenerating ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  Download PDF
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
