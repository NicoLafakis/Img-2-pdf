# Image to PDF

A mobile-friendly web application that converts images into PDF documents. Built with React, Vite, and Tailwind CSS.

![Image to PDF](https://img.shields.io/badge/React-18-blue) ![Vite](https://img.shields.io/badge/Vite-4-purple) ![Tailwind](https://img.shields.io/badge/Tailwind-3-cyan)

## Features

- **Mobile-optimized UI** — Large touch targets and fixed bottom button for easy thumb access
- **Multiple image support** — Add as many images as you need
- **Reorder pages** — Arrange images in any order using up/down controls
- **Rotate images** — Fix sideways photos with 90° rotation
- **Custom filenames** — Name your PDF before downloading
- **Privacy-focused** — Everything runs in your browser; images never leave your device
- **Offline capable** — Works without an internet connection after initial load

## Getting Started

### Prerequisites

- Node.js 16+ 
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/image-to-pdf-app.git
cd image-to-pdf-app

# Install dependencies
npm install

# Start the development server
npm run dev
```

The app will be available at `http://localhost:5173`

### Building for Production

```bash
npm run build
```

The built files will be in the `dist` directory, ready to deploy to any static hosting service.

## Deployment

This app works great with:

- **Vercel** — `vercel deploy`
- **Netlify** — Connect your repo for automatic deploys
- **GitHub Pages** — Use the `dist` folder after building

## Tech Stack

- [React 18](https://react.dev/) — UI framework
- [Vite](https://vitejs.dev/) — Build tool
- [Tailwind CSS](https://tailwindcss.com/) — Styling
- [jsPDF](https://github.com/parallax/jsPDF) — PDF generation
- [Lucide React](https://lucide.dev/) — Icons

## How It Works

1. Images are loaded into the browser using the FileReader API
2. Each image becomes a page in the PDF
3. Images are scaled to fit A4 pages while maintaining aspect ratio
4. Rotation is applied using PDF transformation matrices
5. The final PDF is generated client-side and downloaded directly

## License

MIT License - feel free to use this project however you'd like.
